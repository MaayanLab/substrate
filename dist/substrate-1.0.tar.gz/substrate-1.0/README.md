# Substrate

Substrate is a Python package of ORM models and utility functions shared between GEO2Enrichr and GEN3VA.

To install:

`pip install git+git://github.com/MaayanLab/substrate.git@<BRANCH>`

To force reinstall:

`pip install --upgrade --no-deps --force-reinstall git+git://github.com/MaayanLab/substrate.git@<BRANCH>`